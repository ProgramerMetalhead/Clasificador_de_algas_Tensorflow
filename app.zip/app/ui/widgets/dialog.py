''' app/ui/widgets/dialog.py '''
